# regime_v2 — prototype for the rebuilt growth/inflation regime pipeline

Implements Stages 0–3 of the revision plan against live FRED-MD data.
Design choices agreed: monthly FRED-MD from 1959; 4-state HMM as primary
classifier; quasi-real-time (recursive, final-vintage) estimation.

    pip install pandas numpy statsmodels scikit-learn hmmlearn matplotlib
    python run.py data/fredmd_2026-07.csv      # -> figs/, output/

## Modules
- `regime_v2/data.py`     Stage 1. FRED-MD loader, McCracken–Ng t-codes, 10×IQR outlier rule,
                          growth (22 series) and inflation (13 series) blocks. ULC excluded (quarterly).
- `regime_v2/factors.py`  Stage 2a. One-factor PCA per block with EM imputation of removed cells;
                          sign-anchored to INDPRO / CPIAUCSL; partial-sum diffusion index.
- `regime_v2/trend.py`    Stage 2b. Quasi-real-time gaps: `smoothed_trailing` (default), recursive
                          Hamilton filter, one-sided HP (for comparison); expanding-window standardisation;
                          Orphanides–van Norden revision statistics.
- `regime_v2/regimes.py`  Stage 3. Named regimes (Contraction / Goldilocks / Overheating / Stagflation);
                          deterministic quadrants; constrained HMM (fixed emissions at quadrant centroids,
                          persistence prior — primary); free HMM (challenger).
- `run.py`                Builds everything, writes figs 1–5, `output/regime_labels.csv`,
                          `output/outliers_removed.csv`, `output/summary.json` with acceptance tests.

## What the prototype run shows (FRED-MD 2026-07 vintage, 1969-01..2026-06, 690 months)
- Outlier rule removed 36 cells, 29 of them in 2020 — the COVID months no longer set the scale.
- Acceptance tests: GFC 2008-09..2009-06 -> Contraction 90% (HMM and quadrants);
  COVID 2020-03..06 -> Contraction 75%; 2021-06..2022-12 -> high-inflation 100%;
  every NBER recession month is low-growth (Contraction or Stagflation); Contraction false-alarm
  rate outside NBER recessions 7%.
- HMM (primary): expected durations Contraction 11m, Goldilocks 40m, Overheating 16m, Stagflation 14m;
  71% agreement with the quadrant rule; only 61% of months have max-probability > 0.95
  (v1 GMM was pinned at 1.0 for years).
- Growth-gap revisions (real-time vs ex-post two-sided): corr 0.96, noise/signal 0.28, sign agreement 87%.
- Free HMM (challenger) does NOT recover sign quadrants: it finds a wide crisis state (both
  deflationary and stagflationary busts) and a mild sub-trend state. Worth a paragraph in the paper.

## Design decisions worth flagging in the paper
1. Growth gap operates on the growth *rate* factor (3m MA minus trailing 10y mean), not on a level
   index. A recursive Hamilton filter on the level index produced a persistently negative gap
   through the 2010s because trend growth slowed (fig5 in the first run) — a real-time version of the
   drift problem the memo warned about.
2. Inflation gap: partial sum of the price-block factor (an inflation-rate index), 3m MA minus trailing
   10y mean — i.e. the paper's "slow-moving trend" assumption, made explicit and one-sided.
3. hmmlearn's tied-covariance M-step divides by zero when means are frozen, so the constrained HMM
   freezes covariances too (pooled within-quadrant). Only start/transition probabilities are estimated.

## Known limitations / next steps (Stage 4+)
- PCA loadings and block standardisation are still full-sample. Stage 4 = expanding-window PCA
  and a walk-forward re-fit of the HMM each month; then the random-regime placebo and block bootstrap.
- The trailing-mean trend inherits big episodes: after 2021-22 both trends are inflated, which
  is why 2024-26 reads as Contraction. Options: longer window (15y), trailing median, or a
  Lenza–Primiceri-style down-weighting of 2020-22 in the trend.
- Sample starts 1969 (60-month burn-in for trend + 60 for std). Can be shortened.
- Asset layer (Stages 5–6) not started — needs the nine-asset universe and return source.
