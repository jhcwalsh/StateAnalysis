"""Stage 0–3 prototype run. Produces figs/ and a results summary.

Usage: python run.py data/fredmd_2026-07.csv
"""
import sys
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from regime_v2.data import build_blocks
from regime_v2.factors import pca_factor_em
from regime_v2.trend import make_gap, hamilton_recursive, revision_stats
from regime_v2.regimes import (quadrant_labels, fit_hmm4, transition_table, expected_duration,
                               run_lengths, REGIMES, COLORS)

# NBER recession months (peak->trough, inclusive of trough month)
NBER = [("1960-04", "1961-02"), ("1969-12", "1970-11"), ("1973-11", "1975-03"), ("1980-01", "1980-07"),
        ("1981-07", "1982-11"), ("1990-07", "1991-03"), ("2001-03", "2001-11"), ("2007-12", "2009-06"),
        ("2020-02", "2020-04")]


def nber_flag(index):
    f = pd.Series(False, index=index)
    for a, b in NBER:
        f[(index >= pd.Timestamp(a)) & (index <= pd.Timestamp(b) + pd.offsets.MonthEnd(0))] = True
    return f


def shade_nber(ax):
    for a, b in NBER:
        ax.axvspan(pd.Timestamp(a), pd.Timestamp(b), color="grey", alpha=0.18, lw=0)


PERSIST = 10.0


def main(path):
    blocks = build_blocks(path)
    print(f"growth block: {blocks['growth'].shape[1]} series; inflation block: {blocks['inflation'].shape[1]} series")
    print(f"missing from vintage: {blocks['missing_series']}")
    print(f"outlier cells removed: {len(blocks['outliers'])}")
    print(blocks["outliers"].groupby(blocks["outliers"]["date"].dt.year).size().to_string())

    # --- factors
    gf = pca_factor_em(blocks["growth"], anchor="INDPRO")
    pf = pca_factor_em(blocks["inflation"], anchor="CPIAUCSL")

    # --- gaps (quasi-real-time)
    # growth: the factor is already a growth *rate*; gap = 3m-smoothed rate minus trailing 10y mean
    g_gap = make_gap(gf["factor"], "smoothed_trailing", smooth=3, window=120)
    # inflation: partial sum of the (acceleration) factor is an inflation-rate index; same treatment
    p_gap = make_gap(pf["diffusion"], "smoothed_trailing", smooth=3, window=120)
    G, P = g_gap["gap"], p_gap["gap"]

    # revision diagnostic for growth: quasi-real-time gap (trailing trend, expanding std)
    # vs an ex-post "final" gap using a two-sided centred 10y trend and full-sample std
    sm = gf["factor"].rolling(3, min_periods=1).mean()
    full_gap = (sm - sm.rolling(120, center=True, min_periods=60).mean())
    full_gap = full_gap / full_gap.std()
    rev = revision_stats(G, full_gap)

    # --- regimes
    quad = quadrant_labels(G, P)
    hmm_lab, probs, model, smap = fit_hmm4(G, P, persistence=PERSIST, constrained=True)
    free_lab, free_probs, free_model, free_smap = fit_hmm4(G, P, persistence=PERSIST, constrained=False)
    tm = transition_table(model, smap)
    dur = expected_duration(tm)

    # --- acceptance tests
    def share(labels, a, b, regs):
        s = labels[(labels.index >= a) & (labels.index <= b)]
        return float(s.isin(regs).mean()), int(len(s))

    tests = {
        "GFC 2008-09..2009-06 -> Contraction (HMM)": share(hmm_lab, "2008-09", "2009-06", ["Contraction"]),
        "GFC 2008-09..2009-06 -> Contraction (quadrants)": share(quad, "2008-09", "2009-06", ["Contraction"]),
        "COVID 2020-03..2020-06 -> Contraction (HMM)": share(hmm_lab, "2020-03", "2020-06", ["Contraction"]),
        "Inflation 2021-06..2022-12 -> high-inflation (HMM)": share(hmm_lab, "2021-06", "2022-12", ["Overheating", "Stagflation"]),
        "1973-75 & 1979-82 -> Stagflation share (HMM)": share(hmm_lab, "1973-11", "1982-11", ["Stagflation"]),
    }
    nb = nber_flag(hmm_lab.index)
    low_g = ["Contraction", "Stagflation"]
    tests["NBER months labelled low-growth (Contraction|Stagflation, HMM)"] = (float(hmm_lab[nb].isin(low_g).mean()), int(nb.sum()))
    tests["Non-NBER months labelled Contraction (HMM, false-alarm rate)"] = (float(hmm_lab[~nb].eq("Contraction").mean()), int((~nb).sum()))
    tests["Non-NBER months labelled low-growth (HMM)"] = (float(hmm_lab[~nb].isin(low_g).mean()), int((~nb).sum()))

    # --- figures
    fig, axes = plt.subplots(2, 1, figsize=(12, 6.5), sharex=True)
    for ax, gp, name in zip(axes, [g_gap, p_gap], ["Growth", "Inflation"]):
        ax.plot(gp.index, gp["level"], lw=1, label=f"{name} diffusion index", color="#1c7ed6")
        ax.plot(gp.index, gp["trend"], lw=1.6, label="Recursive trend", color="#e8590c")
        ax2 = ax.twinx()
        ax2.plot(gp.index, gp["gap"], lw=1, color="#2b8a3e", label="Gap (SD, real-time)")
        ax2.axhline(0, color="grey", ls="--", lw=0.8)
        ax2.set_ylabel("gap (SD)")
        shade_nber(ax)
        ax.set_title(f"{name}: level, recursive trend, and quasi-real-time gap")
        ax.legend(loc="upper left", fontsize=8)
        ax2.legend(loc="lower right", fontsize=8)
    fig.tight_layout(); fig.savefig("figs/fig1_factors_gaps.png", dpi=130); plt.close(fig)

    fig, axes = plt.subplots(3, 1, figsize=(13, 6.3), sharex=True)
    for ax, lab, title in zip(axes, [quad, hmm_lab, free_lab],
                              ["Deterministic quadrants", "4-state HMM, means fixed at quadrant centroids (primary)",
                               "4-state HMM, free means/covariances (challenger)"]):
        for r in REGIMES:
            m = lab == r
            ax.fill_between(lab.index, 0, 1, where=m.reindex(lab.index, fill_value=False).to_numpy(), color=COLORS[r], step="mid", lw=0, label=r)
        shade_nber(ax); ax.set_yticks([]); ax.set_title(title)
    axes[0].legend(ncol=4, fontsize=8, loc="upper left", bbox_to_anchor=(0, 1.45))
    fig.tight_layout(); fig.savefig("figs/fig2_regime_timeline.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    df = pd.concat([G, P, hmm_lab], axis=1, keys=["g", "p", "r"]).dropna()
    for r in REGIMES:
        d = df[df["r"] == r]
        ax.scatter(d["g"], d["p"], s=10, color=COLORS[r], label=f"{r} (n={len(d)})", alpha=0.7)
    ax.axhline(0, color="grey", ls="--", lw=0.8); ax.axvline(0, color="grey", ls="--", lw=0.8)
    ax.set_xlabel("Growth gap (SD, real-time)"); ax.set_ylabel("Inflation gap (SD, real-time)")
    ax.set_title("Growth–inflation state space, HMM regimes"); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig("figs/fig3_state_space.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(13, 3.6))
    ax.stackplot(probs.index, [probs[r] for r in REGIMES], colors=[COLORS[r] for r in REGIMES], labels=REGIMES, lw=0)
    shade_nber(ax); ax.set_ylim(0, 1); ax.set_title("HMM smoothed regime probabilities"); ax.legend(ncol=4, fontsize=8, loc="lower left")
    fig.tight_layout(); fig.savefig("figs/fig4_hmm_probabilities.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 3.2))
    ax.plot(G.index, G, lw=0.9, label="Quasi-real-time (recursive)")
    ax.plot(full_gap.index, full_gap, lw=0.9, label="Ex-post (two-sided trend, full-sample std)", alpha=0.8)
    ax.axhline(0, color="grey", ls="--", lw=0.8); shade_nber(ax)
    ax.set_title(f"Growth gap revisions — corr {rev['corr_first_final']:.2f}, N/S {rev['noise_to_signal_rmse']:.2f}, sign agreement {rev['sign_agreement']:.0%}")
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig("figs/fig5_revisions.png", dpi=130); plt.close(fig)

    # --- summary
    summary = {
        "n_months": int(len(hmm_lab)),
        "sample": [str(hmm_lab.index[0].date()), str(hmm_lab.index[-1].date())],
        "regime_counts_hmm": hmm_lab.value_counts().to_dict(),
        "regime_counts_quadrants": quad.value_counts().to_dict(),
        "agreement_hmm_vs_quadrants": float((hmm_lab == quad.reindex(hmm_lab.index)).mean()),
        "agreement_free_hmm_vs_quadrants": float((free_lab == quad.reindex(free_lab.index)).mean()),
        "regime_counts_free_hmm": free_lab.value_counts().to_dict(),
        "free_hmm_state_means": {free_smap[s]: [round(float(v), 2) for v in free_model.means_[s]] for s in range(4)},
        "expected_duration_months": {r: float(d) for r, d in zip(REGIMES, dur)},
        "mean_run_length_months": run_lengths(hmm_lab).round(1).to_dict(),
        "transition_matrix": tm.round(3).to_dict(),
        "share_probs_above_0.95": float((probs.max(axis=1) > 0.95).mean()),
        "growth_gap_revision": rev,
        "acceptance_tests": {k: {"share": round(v[0], 3), "n": v[1]} for k, v in tests.items()},
        "growth_loadings_top": gf.attrs["loadings"].sort_values(ascending=False).round(2).to_dict(),
        "inflation_loadings_top": pf.attrs["loadings"].sort_values(ascending=False).round(2).to_dict(),
    }
    labels_out = pd.concat([G.rename("growth_gap"), P.rename("inflation_gap"), quad.rename("quadrant"), hmm_lab.rename("hmm")], axis=1)
    labels_out = pd.concat([labels_out, probs.add_prefix("p_"), free_lab.rename("hmm_free")], axis=1)
    labels_out.to_csv("output/regime_labels.csv")
    blocks["outliers"].to_csv("output/outliers_removed.csv", index=False)
    with open("output/summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main(sys.argv[1])
