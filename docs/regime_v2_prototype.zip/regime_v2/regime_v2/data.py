"""Stage 1 — data layer.

Loads a FRED-MD vintage CSV, applies the McCracken–Ng t-code transformations,
removes outliers with the FRED-MD rule (|x - median| > 10 * IQR -> NaN),
and returns the growth and inflation blocks used for factor extraction.

Reference: McCracken & Ng (2016), FRED-MD, JBES 34(4).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# Growth block: real activity — mirrors the paper's spec (IP, employment,
# retail sales, housing, unemployment) using FRED-MD mnemonics.
GROWTH_BLOCK = [
    "INDPRO", "IPFINAL", "IPCONGD", "IPBUSEQ", "IPMANSICS", "CUMFNS",
    "PAYEMS", "USGOOD", "MANEMP", "SRVPRD", "USTPU", "HWI",
    "UNRATE", "CLAIMSx", "UEMPMEAN",
    "RETAILx", "DPCERA3M086SBEA", "CMRMTSPLx", "RPI", "W875RX1",
    "HOUST", "PERMIT",
]

# Inflation block: prices and wages. Unit labour costs are quarterly and are
# deliberately excluded from the monthly factor (see review memo §2).
INFLATION_BLOCK = [
    "CPIAUCSL", "CPIULFSL", "CUSR0000SA0L2", "CUSR0000SA0L5",
    "PCEPI", "DNDGRG3M086SBEA", "DSERRG3M086SBEA",
    "WPSFD49207", "WPSFD49502", "PPICMM",
    "CES0600000008", "CES2000000008", "CES3000000008",
]

# Series whose sign runs against the block's economic direction; flipped so
# that "up" = stronger growth / higher inflation before PCA.
COUNTERCYCLICAL = {"UNRATE", "CLAIMSx", "UEMPMEAN"}


def load_fredmd(path: str) -> tuple[pd.DataFrame, pd.Series]:
    """Return (raw levels, t-codes) from a FRED-MD monthly CSV."""
    raw = pd.read_csv(path)
    tcodes = raw.iloc[0, 1:].astype(int)
    tcodes.index = raw.columns[1:]
    df = raw.iloc[1:].copy()
    df["sasdate"] = pd.to_datetime(df["sasdate"])
    df = df.set_index("sasdate").astype(float)
    df.index.name = "date"
    df = df.dropna(how="all")
    return df, tcodes


def transform(x: pd.Series, tcode: int) -> pd.Series:
    """McCracken–Ng transformation codes 1–7."""
    if tcode == 1:
        return x
    if tcode == 2:
        return x.diff()
    if tcode == 3:
        return x.diff().diff()
    if tcode == 4:
        return np.log(x)
    if tcode == 5:
        return np.log(x).diff()
    if tcode == 6:
        return np.log(x).diff().diff()
    if tcode == 7:
        return (x / x.shift(1) - 1.0).diff()
    raise ValueError(f"unknown tcode {tcode}")


def remove_outliers(df: pd.DataFrame, k: float = 10.0) -> tuple[pd.DataFrame, pd.DataFrame]:
    """FRED-MD rule: observations more than k*IQR from the median -> NaN.

    Returns (cleaned, mask) where mask marks the removed cells.
    """
    med = df.median()
    iqr = df.quantile(0.75) - df.quantile(0.25)
    mask = (df - med).abs() > k * iqr
    return df.mask(mask), mask


def build_blocks(path: str, k_outlier: float = 10.0):
    """Load, transform, clean, and split into growth / inflation blocks.

    Returns dict with 'growth', 'inflation' DataFrames (stationary, cleaned),
    plus 'outliers' (long-format list of removed cells) for the data sheet.
    """
    levels, tcodes = load_fredmd(path)
    cols = [c for c in GROWTH_BLOCK + INFLATION_BLOCK if c in levels.columns]
    missing = sorted(set(GROWTH_BLOCK + INFLATION_BLOCK) - set(cols))
    stat = pd.DataFrame({c: transform(levels[c], int(tcodes[c])) for c in cols})
    for c in COUNTERCYCLICAL:
        if c in stat:
            stat[c] = -stat[c]
    cleaned, mask = remove_outliers(stat, k_outlier)
    outliers = mask.stack()
    outliers = outliers[outliers].reset_index()
    outliers.columns = ["date", "series", "removed"]
    growth = cleaned[[c for c in GROWTH_BLOCK if c in cleaned]]
    infl = cleaned[[c for c in INFLATION_BLOCK if c in cleaned]]
    return {
        "growth": growth,
        "inflation": infl,
        "outliers": outliers.drop(columns="removed"),
        "missing_series": missing,
        "tcodes": tcodes[cols],
    }
