"""Stage 2a — factor extraction.

First principal component of each (standardised) block, estimated with a
simple EM loop so outlier-removed cells (NaN) don't force row deletion.
The factor is oriented so it correlates positively with an anchor series
(INDPRO for growth, CPIAUCSL for inflation), then cumulated into a
partial-sum diffusion index (McCracken & Ng 2016, §5) for trend/cycle work.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def _first_pc(X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """First PC scores and loadings of a complete matrix (T x N)."""
    U, s, Vt = np.linalg.svd(X, full_matrices=False)
    loadings = Vt[0]
    scores = X @ loadings
    return scores, loadings


def pca_factor_em(block: pd.DataFrame, anchor: str, n_iter: int = 50, tol: float = 1e-6) -> pd.DataFrame:
    """One-factor PCA with EM imputation of NaN cells.

    Returns DataFrame with columns: factor (monthly, standardised),
    diffusion (partial sum of factor), n_series (non-missing count per month).
    """
    df = block.dropna(how="all")
    mu, sd = df.mean(), df.std()
    Z = ((df - mu) / sd)
    obs = ~Z.isna()
    X = Z.fillna(0.0).to_numpy()
    prev = None
    for _ in range(n_iter):
        scores, load = _first_pc(X)
        recon = np.outer(scores, load)
        X = np.where(obs.to_numpy(), Z.to_numpy(), recon)
        if prev is not None and np.nanmax(np.abs(scores - prev)) < tol:
            break
        prev = scores
    f = pd.Series(scores, index=df.index)
    # orient: positive correlation with anchor's transformed series
    sign = 1.0
    if anchor in df and np.corrcoef(f, Z[anchor].fillna(0))[0, 1] < 0:
        sign = -1.0
    f = sign * f
    f = (f - f.mean()) / f.std()
    out = pd.DataFrame({"factor": f, "diffusion": f.cumsum(), "n_series": obs.sum(axis=1)})
    out.attrs["loadings"] = pd.Series(sign * load, index=df.columns)
    return out
