"""Stage 2b — quasi-real-time gaps.

Every estimator here uses only data up to and including month t when it
produces the gap for month t (Ince & Papell 2013 "quasi-real-time"). No
two-sided filters. Three options:

  hamilton_recursive : Hamilton (2018) regression filter, h=24, p=12 for
                       monthly data, coefficients re-estimated each month
                       on the expanding sample.
  trailing_mean      : deviation from a one-sided rolling mean (default
                       120 months) — the "slow, near-constant trend"
                       assumption the paper makes for inflation.
  onesided_hp        : HP filter re-run each month on data <= t, keeping
                       only the last point (for comparison; NOT recommended).

Gaps are standardised with an expanding-window std so the scale is also
real-time.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from statsmodels.tsa.filters.hp_filter import hpfilter


def hamilton_recursive(y: pd.Series, h: int = 24, p: int = 12, min_obs: int = 120) -> pd.DataFrame:
    y = y.dropna()
    idx = y.index
    vals = y.to_numpy()
    T = len(vals)
    trend = np.full(T, np.nan)
    cycle = np.full(T, np.nan)
    # regressors at s: [1, y_{s-h}, ..., y_{s-h-p+1}]
    lag_mat = np.column_stack([np.roll(vals, h + j) for j in range(p)])
    X_all = np.column_stack([np.ones(T), lag_mat])
    first = h + p - 1
    for t in range(max(first + min_obs, first + p + 2), T):
        X = X_all[first:t + 1]
        Y = vals[first:t + 1]
        beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
        fit = X[-1] @ beta
        trend[t] = fit
        cycle[t] = vals[t] - fit
    out = pd.DataFrame({"level": vals, "trend": trend, "gap_raw": cycle}, index=idx)
    return out


def trailing_mean(y: pd.Series, window: int = 120, min_obs: int = 60) -> pd.DataFrame:
    y = y.dropna()
    tr = y.rolling(window, min_periods=min_obs).mean()
    return pd.DataFrame({"level": y, "trend": tr, "gap_raw": y - tr})


def smoothed_trailing(y: pd.Series, smooth: int = 3, window: int = 120, min_obs: int = 60) -> pd.DataFrame:
    """Trailing-MA smooth of a *rate* series minus its one-sided long-run mean.

    Used for the growth factor (already a standardised monthly growth rate):
    the gap is growth relative to trend growth, so a slowdown in potential
    growth (post-2000) does not read as a permanent negative gap the way a
    level-based filter with drift does.
    """
    y = y.dropna()
    sm = y.rolling(smooth, min_periods=1).mean()
    tr = sm.rolling(window, min_periods=min_obs).mean()
    return pd.DataFrame({"level": sm, "trend": tr, "gap_raw": sm - tr})


def onesided_hp(y: pd.Series, lamb: float = 129600.0, min_obs: int = 120) -> pd.DataFrame:
    y = y.dropna()
    vals = y.to_numpy()
    trend = np.full(len(vals), np.nan)
    for t in range(min_obs, len(vals)):
        _, tr = hpfilter(vals[: t + 1], lamb=lamb)
        trend[t] = tr[-1]
    return pd.DataFrame({"level": vals, "trend": trend, "gap_raw": vals - trend}, index=y.index)


def standardise_expanding(gap: pd.Series, min_obs: int = 60) -> pd.Series:
    """Real-time z-score: divide by expanding std (mean assumed ~0 for a gap)."""
    sd = gap.expanding(min_periods=min_obs).std()
    return gap / sd


def make_gap(y: pd.Series, method: str, **kw) -> pd.DataFrame:
    fn = {"hamilton": hamilton_recursive, "trailing_mean": trailing_mean,
          "smoothed_trailing": smoothed_trailing, "onesided_hp": onesided_hp}[method]
    out = fn(y, **kw)
    out["gap"] = standardise_expanding(out["gap_raw"])
    return out


def revision_stats(first_vintage: pd.Series, final: pd.Series) -> dict:
    """Orphanides–van Norden style reliability diagnostics."""
    df = pd.concat([first_vintage, final], axis=1, keys=["first", "final"]).dropna()
    rev = df["final"] - df["first"]
    return {
        "corr_first_final": float(df.corr().iloc[0, 1]),
        "noise_to_signal_rmse": float(np.sqrt((rev ** 2).mean()) / df["final"].std()),
        "sign_agreement": float((np.sign(df["first"]) == np.sign(df["final"])).mean()),
        "n": int(len(df)),
    }
