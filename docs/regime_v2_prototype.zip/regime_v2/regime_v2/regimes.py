"""Stage 3 — regime classification.

Two classifiers on the same (growth_gap, inflation_gap) input:
  quadrants : deterministic sign rule (reference)
  hmm4      : 4-state Gaussian HMM, means initialised at the quadrant
              centroids so states map 1:1 to named regimes, and a Dirichlet
              persistence prior on the transition matrix (Nystrup et al.
              2020 motivation: time ordering matters; a GMM ignores it).

Named regimes replace Q-numbers everywhere (review memo §4).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from hmmlearn.hmm import GaussianHMM

REGIMES = ["Contraction", "Goldilocks", "Overheating", "Stagflation"]
# (growth sign, inflation sign)
SIGNS = {
    "Contraction": (-1, -1),
    "Goldilocks": (+1, -1),
    "Overheating": (+1, +1),
    "Stagflation": (-1, +1),
}
COLORS = {"Contraction": "#3b5bdb", "Goldilocks": "#2b8a3e", "Overheating": "#f08c00", "Stagflation": "#e03131"}


def quadrant_labels(g: pd.Series, p: pd.Series) -> pd.Series:
    lab = pd.Series(index=g.index, dtype=object)
    for name, (sg, sp) in SIGNS.items():
        m = (np.sign(g) == sg) & (np.sign(p) == sp)
        lab[m] = name
    return lab


def fit_hmm4(g: pd.Series, p: pd.Series, persistence: float = 10.0, seed: int = 0,
             constrained: bool = True):
    """Fit the 4-state HMM. Returns (labels, probs DataFrame, model, state_map).

    constrained=True  : emissions fixed (quadrant-centroid means, pooled
                        within-quadrant covariance); only the transition and
                        start probabilities are estimated. States keep the
                        named-regime semantics and the HMM adds persistence only.
    constrained=False : free means and full covariances (challenger). In
                        practice this finds a wide "crisis" state and a mild
                        "sub-trend" state rather than four sign quadrants.
    """
    X = pd.concat([g, p], axis=1).dropna()
    Xv = X.to_numpy()
    q = quadrant_labels(X.iloc[:, 0], X.iloc[:, 1])
    init_means = np.array([X[q == r].mean().to_numpy() for r in SIGNS])  # empirical centroids
    if constrained:
        # Fixed emissions: quadrant-centroid means and one pooled within-quadrant
        # covariance. Only start/transition probabilities are estimated, so the
        # HMM is a transparent persistence smoother over the quadrant rule.
        # (hmmlearn's tied-covariance M-step divides by zero when means are
        # frozen, so covariances are frozen too.)
        resid = np.vstack([X[q == r].to_numpy() - init_means[i] for i, r in enumerate(SIGNS)])
        model = GaussianHMM(n_components=4, covariance_type="tied", n_iter=500, tol=1e-4,
                            random_state=seed, init_params="s", params="st",
                            transmat_prior=1.0 + persistence * np.eye(4))
        model.means_ = init_means
        model.covars_ = np.cov(resid.T)
    else:
        model = GaussianHMM(n_components=4, covariance_type="full", n_iter=500, tol=1e-4,
                            random_state=seed, init_params="sc", params="stmc",
                            transmat_prior=1.0 + persistence * np.eye(4))
        model.means_ = init_means
    model.transmat_ = np.full((4, 4), 0.02) + np.eye(4) * 0.92
    model.fit(Xv)
    # map fitted states to named regimes by nearest sign pattern of the means
    names = list(SIGNS.keys())
    order = []
    remaining = set(range(4))
    for k in range(4):
        target = init_means[k]
        best = min(remaining, key=lambda s: np.linalg.norm(model.means_[s] - target))
        order.append(best)
        remaining.remove(best)
    state_map = {s: names[k] for k, s in enumerate(order)}
    post = model.predict_proba(Xv)
    probs = pd.DataFrame(post, index=X.index, columns=[state_map[s] for s in range(4)])[REGIMES]
    labels = probs.idxmax(axis=1)
    return labels, probs, model, state_map


def transition_table(model, state_map) -> pd.DataFrame:
    names = [state_map[s] for s in range(4)]
    tm = pd.DataFrame(model.transmat_, index=names, columns=names).loc[REGIMES, REGIMES]
    return tm


def expected_duration(tm: pd.DataFrame) -> pd.Series:
    return 1.0 / (1.0 - np.diag(tm.to_numpy()))


def run_lengths(labels: pd.Series) -> pd.Series:
    """Average consecutive-month run length per regime."""
    runs = {r: [] for r in REGIMES}
    cur, n = None, 0
    for v in labels.dropna():
        if v == cur:
            n += 1
        else:
            if cur is not None:
                runs[cur].append(n)
            cur, n = v, 1
    if cur is not None:
        runs[cur].append(n)
    return pd.Series({r: (np.mean(v) if v else np.nan) for r, v in runs.items()})
